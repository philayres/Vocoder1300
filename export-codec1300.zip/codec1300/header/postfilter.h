/*
 * Copyright (C) 1993-2016 David Rowe
 *
 * All rights reserved
 * 
 * Licensed under GNU LGPL V2.1
 * See LICENSE file for information
 */
#ifndef __POSTFILTER__
#define __POSTFILTER__

#ifdef __cplusplus
extern "C"
{
#endif

void postfilter(MODEL *, float *);

#ifdef __cplusplus
}
#endif
#endif
